import requests
from bs4 import BeautifulSoup
import pandas as pd
import re

url = "https://www.globalfirepower.com/aircraft-total.php"

headers = {
    "User-Agent": "Mozilla/5.0"
}

response = requests.get(url, headers=headers)
soup = BeautifulSoup(response.text, "html.parser")

data = []

# Get page text
text = soup.get_text("\n")

# Pattern: Rank Country Code AircraftCount
pattern = r'(\d+)\s+([A-Za-z\s\-\']+)\s+[A-Z]{3}\s+(\d{1,3}(?:,\d{3})*)'

matches = re.findall(pattern, text)

for rank, country, aircraft in matches:
    data.append([country.strip(), aircraft.replace(",", "")])

# Create DataFrame
df = pd.DataFrame(data, columns=["Country", "Aircraft_Count"])

print(df.head())

# Save to CSV
df.to_csv("country_aircrafts.csv", index=False)

print("Data saved to country_aircrafts.csv")