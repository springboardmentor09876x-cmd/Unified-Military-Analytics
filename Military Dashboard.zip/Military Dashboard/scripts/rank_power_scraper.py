import requests
from bs4 import BeautifulSoup
import pandas as pd
import re

url = "https://www.globalfirepower.com/countries-listing.php"

response = requests.get(
    url,
    headers={"User-Agent":"Mozilla/5.0"}
)

html = response.text

pattern = r'''
rankNumContainer.*?
(\d+)\s*</span>.*?
longFormName.*?
([A-Za-z\s\-\']+)\s*</span>.*?
PwrIndx:\s*([0-9.]+)
'''

matches = re.findall(pattern, html, re.S | re.X)

data = []

for rank, country, pwr in matches:
    data.append([country.strip(), rank, pwr])

df = pd.DataFrame(
    data,
    columns=[
        "Country",
        "Rank",
        "Power_Index"
    ]
)

df.to_csv(
    "../output/country_rank_power.csv",
    index=False
)

print(df.head())
print("Rows:", len(df))
print("Saved")