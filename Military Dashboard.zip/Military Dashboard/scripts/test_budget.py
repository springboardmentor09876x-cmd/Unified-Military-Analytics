
import requests

url = "https://www.globalfirepower.com/defense-spending-budget.php"

response = requests.get(
    url,
    headers={"User-Agent":"Mozilla/5.0"}
)

print("Status:", response.status_code)
print(response.text[:2000])