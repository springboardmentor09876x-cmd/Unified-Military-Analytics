import requests

url = "https://www.globalfirepower.com/countries-listing.php"

response = requests.get(
    url,
    headers={"User-Agent":"Mozilla/5.0"}
)

with open("ranking_page.html","w",encoding="utf-8") as f:
    f.write(response.text)

print("Saved")