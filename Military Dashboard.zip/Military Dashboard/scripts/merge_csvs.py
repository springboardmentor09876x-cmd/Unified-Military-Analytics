import pandas as pd
import glob

files = glob.glob("../output/*.csv")

print("Files Found:", len(files))

df = pd.read_csv(files[0])

for file in files[1:]:
    temp = pd.read_csv(file)

    if "Country" in temp.columns:
        df = pd.merge(df, temp, on="Country", how="outer")

df.to_csv("../data/military_dashboard_dataset.csv", index=False)

print("Rows:", df.shape[0])
print("Columns:", df.shape[1])
print("Merged Successfully!")