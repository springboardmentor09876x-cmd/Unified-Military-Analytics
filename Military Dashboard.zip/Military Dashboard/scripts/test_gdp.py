import requests
from bs4 import BeautifulSoup

url="https://www.globalfirepower.com/purchasing-power-parity.php"

response=requests.get(url,headers={"User-Agent":"Mozilla/5.0"})

print("Status:",response.status_code)

print(response.text[:2000])