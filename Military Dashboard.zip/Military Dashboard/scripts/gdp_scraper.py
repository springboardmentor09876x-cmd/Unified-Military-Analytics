import requests
from bs4 import BeautifulSoup
import pandas as pd
import re

url = "https://www.globalfirepower.com/purchasing-power-parity.php"

response = requests.get(
    url,
    headers={"User-Agent": "Mozilla/5.0"}
)

soup = BeautifulSoup(response.text, "html.parser")
text = soup.get_text("\n")

pattern = r'([A-Za-z\s\-]+)\s+([A-Z]{3})\s+\$\s*([\d,]+)'

data = []

for country, code, gdp in re.findall(pattern, text):
    country = country.strip()

    if len(country) > 2:
        data.append([
            country,
            gdp.replace(",", "")
        ])

df = pd.DataFrame(
    data,
    columns=["Country", "GDP"]
)

df.drop_duplicates(subset=["Country"], inplace=True)

df.to_csv(
    "../output/country_gdp.csv",
    index=False
)

print(df.head())
print("Rows:", len(df))
print("Saved")