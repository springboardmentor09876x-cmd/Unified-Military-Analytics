import requests
import pandas as pd

url = "https://www.globalfirepower.com/countries-listing.php"

headers = {
    "User-Agent": "Mozilla/5.0"
}

response = requests.get(url, headers=headers)

print(response.status_code)

print(response.text[:3000])