import requests
from bs4 import BeautifulSoup

#url = "https://www.globalfirepower.com/defense-spending-budget.php"
url = "https://www.globalfirepower.com/purchasing-power-parity.php"
response = requests.get(
    url,
    headers={"User-Agent":"Mozilla/5.0"}
)

soup = BeautifulSoup(response.text, "html.parser")

text = soup.get_text("\n")

print(text[:10000])