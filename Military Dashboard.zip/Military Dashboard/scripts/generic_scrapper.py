
#1
#url = "https://www.globalfirepower.com/total-population-by-country.php" 
#2
#url="https://www.globalfirepower.com/active-military-manpower.php"
#3
#url="https://www.globalfirepower.com/active-reserve-military-manpower.php"
#4
#url="https://www.globalfirepower.com/armor-tanks-total.php"
#5
#url="https://www.globalfirepower.com/armor-apc-total.php"
#6
#url="https://www.globalfirepower.com/armor-mlrs-total.php"
#7
#url="https://www.globalfirepower.com/aircraft-total-fighters.php"
#8
#url="https://www.globalfirepower.com/aircraft-helicopters-total.php"
#9
#url="https://www.globalfirepower.com/navy-ships.php"
#10
#url="https://www.globalfirepower.com/navy-aircraft-carriers.php"

import requests
from bs4 import BeautifulSoup
import pandas as pd
import re
#11
#url="https://www.globalfirepower.com/navy-destroyers.php"
#12
#url="https://www.globalfirepower.com/navy-frigates.php"
#13
#url="https://www.globalfirepower.com/navy-submarines.php"
#14
#url="https://www.globalfirepower.com/defense-spending-budget.php"
#15
#url="https://www.globalfirepower.com/purchasing-power-parity.php"
#16
#url="https://www.globalfirepower.com/major-serviceable-airports-by-country.php"
#17
#url="https://www.globalfirepower.com/major-ports-and-terminals.php"
#18
#url="https://www.globalfirepower.com/roadway-coverage.php"
#19
#url="https://www.globalfirepower.com/railway-coverage.php"
#20
#url="https://www.globalfirepower.com/square-land-area.php"
#21
#url="https://www.globalfirepower.com/defense-spending-budget.php"
#22
#url="https://www.globalfirepower.com/purchasing-power-parity.php"
#23
url="https://www.globalfirepower.com/aircraft-total.php"

response = requests.get(url, headers={"User-Agent":"Mozilla/5.0"})
soup = BeautifulSoup(response.text,"html.parser")

text = soup.get_text("\n")

pattern = r'(\d+)\s+([A-Za-z\s\-\']+)\s+[A-Z]{3}\s+(\d{1,3}(?:,\d{3})*)'

data=[]

for rank,country,population in re.findall(pattern,text):
    data.append([country.strip(),population.replace(",","")])

df=pd.DataFrame(data,columns=["Country","Total_Aircraft"])

df.to_csv("../output/country_aircrafts.csv",index=False)

print("Saved")