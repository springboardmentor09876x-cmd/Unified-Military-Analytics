import requests
from bs4 import BeautifulSoup
import pandas as pd
import re

url = "https://www.globalfirepower.com/defense-spending-budget.php"

response = requests.get(
    url,
    headers={"User-Agent":"Mozilla/5.0"}
)

soup = BeautifulSoup(response.text, "html.parser")
text = soup.get_text("\n")

pattern = r'([A-Za-z\s\-]+)\s+([A-Z]{3})\s+\$\s*([\d,]+)'

data = []

for country, code, budget in re.findall(pattern, text):
    country = country.strip()

    if len(country) > 2:
        data.append([
            country,
            budget.replace(",", "")
        ])

df = pd.DataFrame(
    data,
    columns=["Country", "Defense_Budget"]
)

df.drop_duplicates(subset=["Country"], inplace=True)

df.to_csv(
    "../output/country_budget.csv",
    index=False
)

print(df.head())
print("Rows:", len(df))
print("Saved")