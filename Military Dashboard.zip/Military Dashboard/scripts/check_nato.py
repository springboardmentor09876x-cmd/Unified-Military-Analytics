import pandas as pd

df = pd.read_csv("../metadata/NATO_1_Country_Stats.csv")

print(df.columns.tolist())
print(df.head())