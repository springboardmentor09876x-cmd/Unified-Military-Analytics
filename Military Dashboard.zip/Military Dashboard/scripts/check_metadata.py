import pandas as pd

df = pd.read_csv("../metadata/Continent Region Country.csv")

print(df.columns.tolist())
print(df.head())